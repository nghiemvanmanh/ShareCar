using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShareCar.Models.Customer.UserModel
{
    public class LoginModel
    {
        public string UserName { get; set; }
        public string PassWord { get; set; }
    }
}